<!-- Footer -->
<footer class="main">
	<span style="text-align:left">
		<strong><?php echo get_phrase('bilal_bin_rabah_center_for_memorizing_quran');?></strong>&nbsp; &copy; 2018
	</span> 
	Supported  by  <a href="http://711.ae" target="_blank">7eleven</a>
</footer>